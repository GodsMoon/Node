package com.kostmo.commute.activity;

public interface Disablable {
	void disable();
	void reEnable();
}
