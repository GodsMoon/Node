package org.achartengine.util;


public interface SemaphoreHost {

	void incSemaphore();
	void decSemaphore();
 }