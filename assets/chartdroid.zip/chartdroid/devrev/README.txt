Google Checkout Notifications API Docs:
http://code.google.com/apis/checkout/developer/Google_Checkout_XML_API_Notification_API.html#new_order_notifications
http://code.google.com/apis/checkout/developer/Google_Checkout_XML_API_Notification_History_API.html

Android Market API:
http://code.google.com/p/android-market-api/

