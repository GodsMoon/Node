package com.kostmo.market.revenue;


public class AuthenticationExpiredException extends Exception {

	private static final long serialVersionUID = 7637435466987324725L;

}
