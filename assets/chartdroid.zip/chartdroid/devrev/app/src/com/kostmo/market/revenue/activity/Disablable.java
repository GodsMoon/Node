package com.kostmo.market.revenue.activity;

public interface Disablable {
	void disable();
	void reEnable();
}
