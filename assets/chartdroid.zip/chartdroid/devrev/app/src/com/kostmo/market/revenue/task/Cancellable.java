package com.kostmo.market.revenue.task;

public interface Cancellable {
	public boolean isCancelled();
}
