package com.kostmo.market.revenue.task;

public interface CancellableProgressIncrementor extends Cancellable, ProgressIncrementor {}
