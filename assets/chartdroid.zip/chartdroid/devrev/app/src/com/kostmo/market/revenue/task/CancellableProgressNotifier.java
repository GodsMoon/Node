package com.kostmo.market.revenue.task;

public interface CancellableProgressNotifier extends Cancellable, ProgressNotifier {}
