package com.kostmo.market.revenue.task;

public interface ProgressIncrementor {

	public void notifyIncrementalProgress(long incremental_progress);
}
