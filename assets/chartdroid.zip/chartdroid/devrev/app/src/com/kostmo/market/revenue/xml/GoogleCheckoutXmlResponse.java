package com.kostmo.market.revenue.xml;

public interface GoogleCheckoutXmlResponse {
	public String getNextPageToken();
	public void setNextPageToken(String token);
}
