package org.crittr.containers;


public interface BareTaxon {

	abstract long getTSN();
}