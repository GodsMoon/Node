package org.crittr.containers;

import java.util.Date;

abstract public class MapPointDated extends MapPoint {

	abstract Date getDate();
	
}