package org.crittr.flickr;

import com.aetrion.flickr.FlickrException;

public interface FlickrFetchRunnable2 {
	
	void fetch() throws FlickrException;

}
