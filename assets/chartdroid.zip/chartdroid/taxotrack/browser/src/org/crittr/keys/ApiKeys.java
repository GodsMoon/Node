package org.crittr.keys;

public class ApiKeys {

	// Populated by build script
	public static final String FLICKR_API_KEY = "";
	public static final String FLICKR_API_SECRET = "";
}
