package org.crittr.shared.browser.containers;

import android.widget.ImageView;
import android.widget.TextView;

public class ViewHolderFlickrPhoto {

    public TextView title, description, owner, id_status;
    public ImageView thumbnail;
}