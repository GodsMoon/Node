package org.crittr.shared.browser.containers;

import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

public class ViewHolderTaxon {
//	public TextView tsn_textview; 
    public TextView taxon_name_textview, taxon_rank_textview, vernacular_name_textview, orphan_textview;
    public RatingBar rating_bar;
    public ImageView thumbnail;
    public View full_view;
}
