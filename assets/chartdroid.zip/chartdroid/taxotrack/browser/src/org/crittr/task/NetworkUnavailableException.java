package org.crittr.task;

public class NetworkUnavailableException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7637435466987324725L;

}
